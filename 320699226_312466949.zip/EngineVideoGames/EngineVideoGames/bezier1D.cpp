#include "bezier1D.h"


Bezier1D::Bezier1D(void)
{
}


Bezier1D::~Bezier1D(void)
{
}
