#include "bezier2D.h"


Bezier2D::Bezier2D(void)
{
}


Bezier2D::~Bezier2D(void)
{
}
